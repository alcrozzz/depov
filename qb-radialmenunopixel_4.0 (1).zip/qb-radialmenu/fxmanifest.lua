fx_version 'adamant'
games { 'gta5' }
client_script {
    "config.lua",
    "client_menu.lua",
	"utils.lua"
}
--------CONVERTED FROM NP-BASE TO QB BY XXXITE-------------

ui_page "nui/dist/index.html"
files {
  "nui/dist/*",
  "nui/dist/index.html",
	"nui/dist/assets/*",
}
